# Legend Client Launcher — Prototype 0.2.0

Android Kotlin + Jetpack Compose starter project.

Included: animated orange L splash, home screen, light/dark themes, rounded orange-outline cards, version section, control preview with size/opacity sliders, settings, and a hidden code dialog.

## Hidden code panel
Tap the launcher title at the top, enter `y000o`, and press Unlock. This opens a demo-only admin panel. It does not access account credentials and never reveals passwords. The code is hard-coded and is not real security.

## Not yet implemented
Minecraft download/launch, Microsoft or Ely.by authentication, mod/loader installation, persistent profiles, actual in-game control integration, skin/cape services. Bedrock is a separate Android app option.

## Build
Open this Gradle project in an Android development environment supporting Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and Android SDK 35. Build the app's debug APK.
