package com.legendclient.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Orange = Color(0xFFFF7900)
private val OrangeSoft = Color(0xFFFFE5D1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LegendApp() }
    }
}

@Composable
fun LegendApp() {
    var dark by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("Home") }
    var splash by remember { mutableStateOf(true) }
    var showCode by remember { mutableStateOf(false) }
    var code by remember { mutableStateOf("") }
    var unlocked by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(1000); splash = false }

    val bg = if (dark) Color(0xFF111114) else Color(0xFFF8F8FA)
    val panel = if (dark) Color(0xFF1D1D22) else Color.White
    val fg = if (dark) Color(0xFFF7F7F8) else Color(0xFF202024)
    val muted = if (dark) Color(0xFFB9B9C2) else Color(0xFF707078)

    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Orange, background = bg, surface = panel)
        else lightColorScheme(primary = Orange, background = bg, surface = panel)) {
        if (splash) SplashScreen() else {
            Scaffold(containerColor = bg, bottomBar = {
                NavigationBar(containerColor = panel) {
                    listOf("Home", "Versions", "Controls", "Settings").forEach { item ->
                        val icon = when (item) {
                            "Home" -> Icons.Filled.Home
                            "Versions" -> Icons.Filled.List
                            "Controls" -> Icons.Filled.Gamepad
                            else -> Icons.Filled.Settings
                        }
                        NavigationBarItem(selected = page == item, onClick = { page = item },
                            icon = { Icon(icon, contentDescription = item) }, label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Orange,
                                selectedTextColor = Orange, indicatorColor = OrangeSoft))
                    }
                }
            }) { padding ->
                Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).background(Orange, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                            Text("L", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f).clickable { showCode = true }) {
                            Text("LEGEND CLIENT", color = fg, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text("LAUNCHER", color = Orange, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 3.sp)
                        }
                        IconButton(onClick = { dark = !dark }) {
                            Icon(if (dark) Icons.Filled.LightMode else Icons.Filled.DarkMode, contentDescription = "Toggle theme", tint = Orange)
                        }
                    }
                    Spacer(Modifier.height(22.dp))
                    when (page) {
                        "Home" -> HomePage(panel, fg, muted) { page = it }
                        "Versions" -> VersionsPage(panel, fg, muted)
                        "Controls" -> ControlsPage(panel, fg, muted)
                        else -> SettingsPage(panel, fg, muted, dark) { dark = it }
                    }
                }
            }
        }
        if (showCode) {
            AlertDialog(
                onDismissRequest = { showCode = false; code = "" },
                title = { Text(if (unlocked) "Legend Admin Panel" else "Enter launcher code") },
                text = {
                    if (unlocked) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Admin panel unlocked.", fontWeight = FontWeight.Bold)
                            Text("This prototype does not store account credentials. Passwords and Microsoft tokens are never shown.")
                            Text("Future safe options: view account type/status, remove profiles, and sign out.")
                        }
                    } else {
                        OutlinedTextField(value = code, onValueChange = { code = it }, singleLine = true,
                            label = { Text("Launcher code") }, shape = RoundedCornerShape(14.dp))
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (unlocked) { unlocked = false; showCode = false; code = "" }
                        else if (code == "y000o") { unlocked = true; code = "" }
                    }) { Text(if (unlocked) "Close" else "Unlock", color = Orange) }
                },
                dismissButton = { if (!unlocked) TextButton(onClick = { showCode = false; code = "" }) { Text("Cancel") } },
                shape = RoundedCornerShape(24.dp), containerColor = panel
            )
        }
    }
}

@Composable fun SplashScreen() {
    val scale by animateFloatAsState(1f, tween(700), label = "scale")
    Box(Modifier.fillMaxSize().background(Color.White), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(112.dp).scale(scale).background(Orange, RoundedCornerShape(32.dp)), contentAlignment = Alignment.Center) {
                Text("L", color = Color.White, fontSize = 78.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(18.dp))
            Text("LEGEND CLIENT", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color(0xFF202024))
            Text("LAUNCHER", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Orange, letterSpacing = 5.sp)
        }
    }
}

@Composable fun HomePage(panel: Color, fg: Color, muted: Color, navigate: (String) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Color(0xFFFFF1E7), RoundedCornerShape(28.dp)).padding(20.dp)) {
                Text("YOUR NEXT WORLD", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                Spacer(Modifier.height(8.dp))
                Text("Ready to play?", color = fg, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text("Choose a Java profile or open your Bedrock game.", color = muted, fontSize = 13.sp)
                Spacer(Modifier.height(18.dp))
                Button(onClick = { navigate("Versions") }, colors = ButtonDefaults.buttonColors(containerColor = Orange),
                    shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().height(54.dp)) {
                    Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("CHOOSE VERSION", fontWeight = FontWeight.ExtraBold)
                }
            }
        }
        item { SectionTitle("QUICK ACCESS", fg) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickCard("Versions", "Java profiles", Icons.Filled.List, panel, fg, Modifier.weight(1f)) { navigate("Versions") }
                QuickCard("Controls", "Touch layout", Icons.Filled.Gamepad, panel, fg, Modifier.weight(1f)) { navigate("Controls") }
            }
        }
        item {
            OutlinedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp),
                border = BorderStroke(1.5.dp, Orange), colors = CardDefaults.outlinedCardColors(containerColor = panel)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Info, null, tint = Orange); Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Prototype build", color = fg, fontWeight = FontWeight.Bold)
                        Text("Game launching, account sign-in, and mod installation are not implemented yet.", color = muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
@Composable fun QuickCard(title: String, subtitle: String, icon: ImageVector, panel: Color, fg: Color, modifier: Modifier, onClick: () -> Unit) {
    OutlinedCard(modifier = modifier.clickable { onClick() }, shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.2.dp, Orange), colors = CardDefaults.outlinedCardColors(containerColor = panel)) {
        Column(Modifier.padding(16.dp)) {
            Icon(icon, null, tint = Orange, modifier = Modifier.size(26.dp)); Spacer(Modifier.height(14.dp))
            Text(title, color = fg, fontWeight = FontWeight.Bold); Text(subtitle, color = Color.Gray, fontSize = 12.sp)
        }
    }
}
@Composable fun VersionsPage(panel: Color, fg: Color, muted: Color) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionTitle("VERSION MANAGER", fg) }
        item { Text("Installation is planned for a later development stage.", color = muted, fontSize = 13.sp) }
        item { VersionCard("Vanilla Java", "Standard Minecraft Java profile", panel, fg, muted) }
        item { VersionCard("Fabric", "Lightweight mod loader", panel, fg, muted) }
        item { VersionCard("Forge", "Mod loader for compatible versions", panel, fg, muted) }
        item { VersionCard("Bedrock Edition", "Open the official Android game", panel, fg, muted) }
        item { Text("Planned mod support: Sodium • Lithium • Iris • Modrinth • CurseForge (where compatible/permitted).", color = muted, fontSize = 12.sp) }
    }
}
@Composable fun VersionCard(title: String, desc: String, panel: Color, fg: Color, muted: Color) {
    OutlinedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, Orange),
        colors = CardDefaults.outlinedCardColors(containerColor = panel)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(OrangeSoft, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Filled.Extension, null, tint = Orange) }
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) {
                Text(title, color = fg, fontWeight = FontWeight.Bold); Text(desc, color = muted, fontSize = 12.sp)
            }
            Text("PLANNED", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}
@Composable fun ControlsPage(panel: Color, fg: Color, muted: Color) {
    var size by remember { mutableFloatStateOf(50f) }
    var opacity by remember { mutableFloatStateOf(75f) }
    var layout by remember { mutableStateOf("Default") }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { SectionTitle("TOUCH CONTROLS", fg) }
        item { Text("Preview only: these values do not yet change in-game controls.", color = muted, fontSize = 13.sp) }
        item {
            Box(Modifier.fillMaxWidth().height(220.dp).background(Color(0xFF30333A), RoundedCornerShape(24.dp)).padding(14.dp)) {
                Text("CONTROL PREVIEW", color = Color.White.copy(alpha = .6f), fontSize = 10.sp, modifier = Modifier.align(Alignment.TopCenter))
                Column(Modifier.align(Alignment.BottomStart), horizontalAlignment = Alignment.CenterHorizontally) {
                    ControlKey("▲", size, opacity)
                    Row { ControlKey("◀", size, opacity); ControlKey("●", size, opacity); ControlKey("▶", size, opacity) }
                    ControlKey("▼", size, opacity)
                }
                Column(Modifier.align(Alignment.BottomEnd), horizontalAlignment = Alignment.End) {
                    ControlKey("JUMP", size, opacity); Spacer(Modifier.height(8.dp)); ControlKey("SNEAK", size, opacity)
                }
            }
        }
        item { SettingCard(panel) {
            Text("Button size: ${size.toInt()}%", color = fg, fontWeight = FontWeight.Bold)
            Slider(size, { size = it }, valueRange = 30f..100f, colors = SliderDefaults.colors(thumbColor = Orange, activeTrackColor = Orange))
            Text("Opacity: ${opacity.toInt()}%", color = fg, fontWeight = FontWeight.Bold)
            Slider(opacity, { opacity = it }, valueRange = 20f..100f, colors = SliderDefaults.colors(thumbColor = Orange, activeTrackColor = Orange))
        } }
        item { SettingCard(panel) {
            Text("Saved layout (preview)", color = fg, fontWeight = FontWeight.Bold)
            var expanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { expanded = true }, border = BorderStroke(1.dp, Orange)) { Text(layout); Icon(Icons.Filled.ArrowDropDown, null, tint = Orange) }
                DropdownMenu(expanded, { expanded = false }) {
                    listOf("Default", "Compact", "PvP", "Builder").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { layout = it; expanded = false }) }
                }
            }
        } }
    }
}
@Composable fun ControlKey(label: String, size: Float, opacity: Float) {
    Box(Modifier.padding(2.dp).size((size * .72f).dp.coerceIn(22.dp, 74.dp)).background(Orange.copy(alpha = opacity / 100f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
        Text(label, color = Color.White, fontSize = if (label.length > 2) 8.sp else 16.sp, fontWeight = FontWeight.ExtraBold)
    }
}
@Composable fun SettingsPage(panel: Color, fg: Color, muted: Color, dark: Boolean, setDark: (Boolean) -> Unit) {
    var animations by remember { mutableStateOf(true) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionTitle("SETTINGS", fg) }
        item { SettingCard(panel) {
            Text("Appearance", color = fg, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Switch between light and dark themes.", color = muted, fontSize = 12.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (dark) "Dark mode" else "Light mode", color = fg, modifier = Modifier.weight(1f))
                Switch(dark, setDark, colors = SwitchDefaults.colors(checkedThumbColor = Orange, checkedTrackColor = OrangeSoft))
            }
        } }
        item { SettingCard(panel) {
            Text("Interface", color = fg, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Smooth animations", color = fg, modifier = Modifier.weight(1f))
                Switch(animations, { animations = it }, colors = SwitchDefaults.colors(checkedThumbColor = Orange, checkedTrackColor = OrangeSoft))
            }
        } }
        item { SettingCard(panel) {
            Text("Accounts (planned)", color = fg, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Microsoft / Ely.by sign-in requires secure integration in a later stage. Passwords are never exposed.", color = muted, fontSize = 12.sp)
        } }
        item { SettingCard(panel) {
            Text("About", color = fg, fontWeight = FontWeight.Bold)
            Text("Legend Client Launcher • Prototype 0.2.0", color = muted, fontSize = 12.sp)
        } }
    }
}
@Composable fun SettingCard(panel: Color, content: @Composable ColumnScope.() -> Unit) {
    OutlinedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), border = BorderStroke(1.3.dp, Orange),
        colors = CardDefaults.outlinedCardColors(containerColor = panel)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}
@Composable fun SectionTitle(title: String, fg: Color) {
    Text(title, color = fg, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
}
