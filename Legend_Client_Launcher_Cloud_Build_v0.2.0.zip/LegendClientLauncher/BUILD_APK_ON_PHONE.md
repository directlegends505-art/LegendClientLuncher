# Build the APK from an Android phone (cloud build)

This repository includes a GitHub Actions workflow that builds a **debug APK** in the cloud. It does not require Android Studio or a PC, but it does require a GitHub account and one initial upload of this project.

1. Create a new GitHub repository and upload the contents of this folder (the `LegendClientLauncher` folder contents, not the parent folder).
2. Open the repository's **Actions** tab.
3. Select **Build Legend Client Launcher APK** and tap **Run workflow** (or push to `main`).
4. Open the completed workflow run and download the artifact named `Legend-Client-Launcher-debug-apk`.
5. Extract the downloaded artifact ZIP on your phone, tap `app-debug.apk`, and allow installation from that source if Android asks.

This produces a debug build, not a Play Store release. The app is still a UI prototype: Minecraft launching, account authentication, mod downloads, skins/capes, and in-game controls are not implemented yet.
